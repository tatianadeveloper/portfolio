import React, { Component } from 'react';
import Card from 'react-bootstrap/Card';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

export default class EducationCard extends Component {
  render() {
    const {
      name,
      location,
      link,
      dataStart,
      dataFinish,
      qualification,
      comment,
    } = this.props.education;
    return (
      <>
        <Card
          border='Light'
          className='mx-auto my-3 shadow-sm'
          style={{ width: '60%' }}
        >
          <Card.Header>
            <Card.Title>{qualification}</Card.Title>
          </Card.Header>
          <Card.Body>
            <Card.Subtitle className='mb-2 text-muted'>
              <a href={link} target='_blank'>
                {name}
              </a>{' '}
              {location}, {dataStart}-{dataFinish}
            </Card.Subtitle>
            <Card.Text>{comment}</Card.Text>
          </Card.Body>
        </Card>
      </>
    );
  }
}
