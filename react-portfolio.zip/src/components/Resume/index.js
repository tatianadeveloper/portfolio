import React, { Component } from 'react';
import { Document, Page } from 'react-pdf';

import resume from './CV.pdf';

export default class Resume extends Component {
  render() {
    return (
      <div>
        <Document file={resume}>
          <Page pageNumber={1} />
        </Document>
      </div>
    );
  }
}
