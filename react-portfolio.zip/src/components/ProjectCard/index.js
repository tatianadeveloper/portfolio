import React, { Component } from 'react';
import Card from 'react-bootstrap/Card';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import ListGroup from 'react-bootstrap/ListGroup';
import logo from '../../images/projects/placeholder.png';
import Image from 'react-bootstrap/Image';

export default class ProjectCard extends Component {
  render() {
    const { name, description, stack, feature } = this.props.project;
    const photoStyle = {
      width: '300px',
      height: '150px',
    };
    const styleLogo = {
      margin: '5px',
      height: '40px',
      width: '40px',
    };
    return (
      <>
        <Card border='Light' className='focus mt-3 mb-3 shadow-sm'>
          <Card.Header>
            <Card.Title>{name}</Card.Title>
          </Card.Header>
          <Container>
            <Row>
              <Col class='mx-auto'>
                <Card.Img variant='top' src={logo} style={photoStyle} />
                <Card.Body>
                  <Card.Link href='#'> GitHub </Card.Link>
                  <Card.Link href='#'> See live </Card.Link>
                </Card.Body>
              </Col>
              <Col>
                <Card.Body>
                  <Card.Text>{description}</Card.Text>
                </Card.Body>
                <ul className='list-group-flush'>
                  {feature.map((el) => {
                    return <li>{el}</li>;
                  })}
                </ul>
              </Col>
            </Row>
          </Container>

          <Card.Footer className='text-muted'>
            {stack.map((el) => {
              return (
                <a href={el.link} target='_blank'>
                  <Image src={el.location} alt='' style={styleLogo} />
                </a>
              );
            })}
          </Card.Footer>
        </Card>
      </>
    );
  }
}
