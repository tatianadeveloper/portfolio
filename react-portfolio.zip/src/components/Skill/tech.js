import React, { Component } from 'react';
import ListGroup from 'react-bootstrap/ListGroup';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Image from 'react-bootstrap/Image';
import Navbar from 'react-bootstrap/Navbar';
import Nav from 'react-bootstrap/Nav';
import { Link } from 'react-router-dom';

export default class Tech extends Component {
  render() {
    const info = this.props.info;
    const { link, location, name } = this.props.stack;
    const styleLogo = {
      height: '40px',
      width: '40px',
    };
    return (
      <>
        <ListGroup.Item>
          <Container>
            <Row>
              <Col sm={3}>
                <a href={link} target='_blank'>
                  <Image src={location} style={styleLogo} />
                  <p>{name}</p>
                </a>
              </Col>
              <Col sm={9}>
                <ul className='list-group-flush'>
                  {info.map((el) => {
                    return <li>{el}</li>;
                  })}{' '}
                </ul>
              </Col>
            </Row>
          </Container>
        </ListGroup.Item>
      </>
    );
  }
}
