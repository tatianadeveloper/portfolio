import React, { Component } from 'react';
import Card from 'react-bootstrap/Card';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import CardGroup from 'react-bootstrap/CardGroup';
import CardColumns from 'react-bootstrap/CardColumns';
import ListGroup from 'react-bootstrap/ListGroup';
import Tech from './tech.js';

export default class Skill extends Component {
  render() {
    const skills = this.props.skills;
    const name = this.props.name;
    return (
      <React.Fragment>
        <Card
          border='Light'
          className='mx-auto my-3 shadow-sm'
          style={{ width: '60%' }}
        >
          <Card.Header>
            <Card.Title>{name}</Card.Title>
          </Card.Header>

          <ListGroup variant='flush'>
            {skills.map((el) => {
              return <Tech key={el.key} info={el.info} stack={el.stack} />;
            })}
          </ListGroup>
        </Card>
      </React.Fragment>
    );
  }
}
