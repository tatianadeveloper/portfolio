import React, { Component } from 'react';
import LinkedinLogo from '../../images/icons/linkedin.svg';
import GitHubLogo from '../../images/icons/github.svg';
import Container from 'react-bootstrap/Container';
import CardDeck from 'react-bootstrap/CardDeck';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

export default class Contact extends Component {
  render() {
    const LogoStyle = {
      margin: '20px',
      height: '20px',
      //width: '20px',
    };
    const ContainerStyle = {
      width: '75%',
      paddingTop: '70px',
    };
    return (
      <>
        <div>
          <Container style={ContainerStyle}>
            <Row>
              <Col>
                <article>
                  <p>
                    <a
                      href='https://www.linkedin.com/in/tatianaprudnikova/'
                      target='_blank'
                    >
                      <img
                        alt='linkedin'
                        src={LinkedinLogo}
                        style={LogoStyle}
                      />
                    </a>
                    Don not hesitate to contact me if you are looking for a team
                    member for your React project
                  </p>
                  <p>
                    <a
                      href='https://github.com/tatianadeveloper'
                      target='_blank'
                    >
                      <img alt='github' src={GitHubLogo} style={LogoStyle} />
                    </a>
                    View source on GitHub
                  </p>
                </article>
              </Col>
            </Row>
          </Container>
        </div>
      </>
    );
  }
}
