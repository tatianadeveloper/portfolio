import React, { Component } from 'react';
import CardDeck from 'react-bootstrap/CardDeck';
import Skill from '../Skill';
import { DataSkills } from '../../Data/Skills.js';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import ListGroup from 'react-bootstrap/ListGroup';

export default class Skills extends Component {
  /*state = {
    skills: DataSkills,
  };*/
  render() {
    //const { skills } = this.state;
    return (
      <>
        <Container>
          <Row>
            <Col>
              {Object.keys(DataSkills).map((el) => {
                return <Skill key={el} name={el} skills={DataSkills[el]} />;
              })}
            </Col>
          </Row>
        </Container>
      </>
    );
  }
}
