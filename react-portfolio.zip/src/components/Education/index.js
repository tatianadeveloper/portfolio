import React, { Component } from 'react';
import EducationCard from '../EducationCard';
import { DataEducation } from '../../Data/Education.js';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

export default class Education extends Component {
  /*state = {
    education: DataEducation,
  };*/
  render() {
    //const { education } = this.state;
    return (
      <>
        <Container>
          <Row>
            <Col>
              {DataEducation.map((el) => {
                return <EducationCard key={el.id} education={el} />;
              })}
            </Col>
          </Row>
        </Container>
      </>
    );
  }
}
