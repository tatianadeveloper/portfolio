import React, { Component } from 'react';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Media from 'react-bootstrap/Media';
import logo from '../../images/PrudnikovaTatianaRound.jpg';

export default class About extends Component {
  render() {
    return (
      <React.Fragment>
        <Container className='mx-auto my-5 w-75'>
          <Row>
            <Col>
              <article>
                <section>
                  {' '}
                  I am a passionate web developer with strong knowledge of
                  JavaScript and React.
                </section>
                <section className=' mt-2'>
                  I used to work as an enterprise business application developer
                  and consultant for over ten years that gave me an experience
                  in problem solving, user communications and designing
                  relational databases.
                </section>
                <section className=' mt-3'>
                  I used to be a math nerd and my hobby was to solve competitive
                  math tasks that formed my mind-set and the way I think and
                  solve problems.
                </section>
                <section className=' mt-3'>
                  My main features are curiosity and attention to details. I
                  like to understand how things work and constantly improve my
                  knowledge.
                </section>
                <section className=' mt-3'>
                  Except of studying web development I enjoy hiking and mountin
                  biking, playing board games and watching short films.
                </section>
              </article>
            </Col>
          </Row>
        </Container>
      </React.Fragment>
    );
  }
}
