import React, { Component } from 'react';
import { DataProjects } from '../../Data/Projects.js';
import ProjectCard from '../ProjectCard';
import Container from 'react-bootstrap/Container';
import CardDeck from 'react-bootstrap/CardDeck';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

export default class Project extends Component {
  render() {
    //const { projects } = DataProjects;
    const ContainerStyle = {
      width: '75%',
    };
    return (
      <>
        <Container style={ContainerStyle}>
          <Row>
            <Col>
              {DataProjects.map((el) => {
                return <ProjectCard key={el.id} project={el} />;
              })}
            </Col>
          </Row>
        </Container>
      </>
    );
  }
}
