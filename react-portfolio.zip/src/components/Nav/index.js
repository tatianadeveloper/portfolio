import React, { Component } from 'react';
import { NavLink, Link, withRouter } from 'react-router-dom';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';

import photo from '../../images/PrudnikovaTatianaReactDeveloperLogo.jpg';
import Image from 'react-bootstrap/Image';

class NavHeader extends Component {
  constructor(props) {
    super(props);
    this.state = {
      displayLogo: true,
    };
  }

  changePage = () => {
    let displayLogo = true;
    switch (window.location.pathname) {
      case '/':
        displayLogo = false;
        break;

      default:
        displayLogo = true;
        break;
    }
    this.setState({
      displayLogo: displayLogo,
    });
  };
  componentDidMount() {
    this.changePage();
    this.props.history.listen(() => {
      this.changePage();
    });
  }
  render() {
    const activeStyle = {
      fontWeight: 'bold',
      //color: 'red',
    };
    const photoStyle = {
      margin: '20px',
      width: '40px',
      height: '40px',
      //borderRadius: '50%',
    };
    const navRoutes = [
      { name: 'About', path: '/about' },
      { name: 'Skills', path: '/skills' },
      { name: 'Education', path: '/education' },
      { name: 'Projects', path: '/projects' },
      { name: 'Experience', path: '/experience' },
      { name: 'Resume', path: '/resume' },
      { name: 'Contact', path: '/contact' },
    ];

    return (
      <>
        <Navbar
          style={{
            marginTop: '10px',
            backgroundColor: 'white',
            borderRadius: '10px',
            height: '60px',
          }}
          sticky='top'
          collapseOnSelect
          expand='lg'
          className='mr-auto shadow-sm'
        >
          {this.state.displayLogo ? (
            <Navbar.Brand as={NavLink} exact to='/'>
              <Image
                src={photo}
                style={photoStyle}
                alt='profile image'
                roundedCircle
              />
              Tatiana
            </Navbar.Brand>
          ) : (
            <></>
          )}

          <Navbar.Toggle aria-controls='responsive-navbar-nav' />
          <Navbar.Collapse
            expand='lg'
            id='responsive-navbar-nav'
            className='justify-content-end'
          >
            <Nav className='ml-auto'>
              {navRoutes.map((route) => {
                return (
                  <Nav.Link
                    as={NavLink}
                    to={route.path}
                    activeStyle={activeStyle}
                  >
                    {route.name}
                  </Nav.Link>
                );
              })}
            </Nav>
          </Navbar.Collapse>
        </Navbar>
      </>
    );
  }
}

export default withRouter(NavHeader);
