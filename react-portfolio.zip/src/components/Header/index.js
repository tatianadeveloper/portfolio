import React, { Component } from 'react';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Media from 'react-bootstrap/Media';
import Image from 'react-bootstrap/Image';
import { Link } from 'react-router-dom';

import logo from '../../images/PrudnikovaTatianaRound.jpg';
import LinkedinLogo from '../../images/icons/linkedin.svg';
import heart from '../../images/Heart.svg';
import GitHubLogo from '../../images/icons/github.svg';

export default class Header extends Component {
  render() {
    const photoStyle = {
      width: '240px',
      height: '240px',
    };
    const LogoStyle = {
      margin: '20px',
      height: '20px',
    };
    const contactStyle = {
      textAlign: 'center',
    };

    return (
      <React.Fragment>
        <Container fluid className=' mt-5'>
          <Row>
            <Col md={{ offset: 2 }}>
              <figure className='blockquote text-left'>
                <blockquote>
                  {' '}
                  "So if you want to go fast, if you want to get done quickly,
                  if you want your code to be easy to write, make it easy to
                  read"
                </blockquote>
                <figcaption className='blockquote-footer'>
                  Robert C. Martin, The Clean Coder: A Code of Conduct for
                  Professional Programmers
                </figcaption>
              </figure>
              <article>
                <section style={{ marginTop: '40px' }}>
                  Hello! I am Tatiana, a Full Stack Web developer living in
                  Auckland, New Zealand who
                  <Image
                    src={heart}
                    style={{ width: '20px', margin: '5px' }}
                  />{' '}
                  React seeking an opportunities to build UI with React and some
                  magic.
                </section>
                <section style={{ marginTop: '30px' }}>
                  <h4>Tech stack:</h4>
                  JavaScript, React, Redux, Node.js, Express, MongoDB
                </section>
              </article>
            </Col>
            <Col class='mx-auto' md={{ span: 3 }}>
              <div>
                <Image
                  src={logo}
                  style={photoStyle}
                  className='align-self-center'
                  alt='logo'
                  roundedCircle
                />
              </div>
              <div style={contactStyle}>
                <a
                  href='https://www.linkedin.com/in/tatianaprudnikova/'
                  target='_blank'
                >
                  <Image src={LinkedinLogo} style={LogoStyle} />
                </a>

                <a href='https://github.com/tatianadeveloper' target='_blank'>
                  <Image src={GitHubLogo} style={LogoStyle} />
                </a>
              </div>
            </Col>
          </Row>
        </Container>
      </React.Fragment>
    );
  }
}
