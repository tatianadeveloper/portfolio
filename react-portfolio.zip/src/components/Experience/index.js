import React, { Component } from 'react';
import ExperienceCard from '../ExperienceCard';
import { DataExperience } from '../../Data/Experience.js';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

export default class Experience extends Component {
  render() {
    // const { experience } = DataExperience;
    return (
      <>
        <Container>
          <Row>
            <Col>
              {DataExperience.map((el) => {
                return <ExperienceCard key={el.id} experience={el} />;
              })}
            </Col>
          </Row>
        </Container>
      </>
    );
  }
}
