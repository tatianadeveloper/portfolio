import React, { Component } from 'react';
import Container from 'react-bootstrap/Container';

import './App.css';

import NavHeader from './components/Nav';
import Header from './components/Header';
import About from './components/About';
import Skills from './components/Skills';
import Education from './components/Education';
import Project from './components/Project';
import Experience from './components/Experience';
import Contact from './components/Contact';
import Resume from './components/Resume';

import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';

export default class App extends Component {
  render() {
    return (
      <Router>
        <Container fluid={true}>
          <NavHeader />
          <Switch>
            <Route path='/about' component={About} />
            <Route path='/skills' component={Skills} />
            <Route path='/education' component={Education} />
            <Route path='/projects' component={Project} />
            <Route path='/experience' component={Experience} />
            <Route path='/resume' component={Resume} />
            <Route path='/contact' component={Contact} />
            <Route path='/' component={Header} />
          </Switch>
        </Container>
      </Router>
    );
  }
}
