import { DataStack } from './Stack.js';

export const DataSkills = {
  Languages: [
    {
      key: 0,
      stack: DataStack.js,
      info: [
        'ES6+',
        'Object-oriented programming with design patterns and SOLID',
        'Functional programming',
        'Asynchronous programming with Promise',
        'DOM API',
        'Event Loop',
      ],
    },

    {
      key: 1,
      stack: DataStack.ts,
      info: [
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
      ],
    },
    {
      key: 1,
      stack: DataStack.html5,
      info: [
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
      ],
    },
    {
      key: 1,
      stack: DataStack.css3,
      info: [
        'Responsive design',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
      ],
    },
  ],
  'Frameworks/libraries': [
    {
      key: 0,
      stack: DataStack.react,
      info: [
        'Functional and class components',
        'React Hooks',
        'React Routes',
        'Styled Components',
        'Form validation',
        'Authentication',
      ],
    },
    {
      key: 1,
      stack: DataStack.redux,
      info: [
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
      ],
    },

    {
      key: 2,
      stack: DataStack.reactBootstrap,
      info: [
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
      ],
    },
    {
      key: 3,
      stack: DataStack.reactRouter,
      info: [
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
      ],
    },
  ],

  Databases: [
    {
      key: 0,
      stack: DataStack.mongodb,
      info: [
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
      ],
    },
    {
      key: 1,
      stack: DataStack.mongodb,
      info: ['ERD', 'T-SQL'],
    },
  ],
  Backend: [
    {
      key: 0,
      stack: DataStack.node,
      info: [
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
      ],
    },
    {
      key: 1,
      stack: DataStack.express,
      info: [
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
      ],
    },
    {
      key: 2,
      stack: DataStack.next,
      info: ['server-side rendering'],
    },
  ],
  Testing: [
    {
      key: 0,
      stack: DataStack.jest,
      info: [
        'unit-testing',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
      ],
    },
  ],
  Tools: [
    {
      key: 0,
      stack: DataStack.webpack,
      info: [
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
      ],
    },
    {
      key: 1,
      stack: DataStack.git,
      info: [
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
      ],
    },
    {
      key: 2,
      stack: DataStack.github,
      info: [
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
      ],
    },
    {
      key: 3,
      stack: DataStack.postman,
      info: [
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
      ],
    },
  ],
};
