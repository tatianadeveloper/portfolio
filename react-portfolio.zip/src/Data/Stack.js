import react from '../images/icons/react.svg';
import node from '../images/icons/nodejs.svg';
import javaScript from '../images/icons/javascript.svg';
import typeScript from '../images/icons/typescript.svg';
import css3 from '../images/icons/css3.svg';
import html5 from '../images/icons/html5.svg';
import reactBootstrap from '../images/icons/react-bootstrap.svg';
import reactRouter from '../images/icons/react-router.svg';
import redux from '../images/icons/redux.svg';
import webpack from '../images/icons/webpack.svg';
import nmp from '../images/icons/npm.svg';
import babel from '../images/icons/babel.svg';
import jest from '../images/icons/jest.svg';
import mongodb from '../images/icons/mongodb.svg';
import express from '../images/icons/express.svg';
import next from '../images/icons/nextjs.svg';
import git from '../images/icons/git.svg';
import github from '../images/icons/github.svg';
import postman from '../images/icons/postman.svg';

export const DataStack = {
  react: {
    name: 'React',
    location: react,
    link: 'https://reactjs.org/',
  },
  js: {
    name: 'JavaScript',
    location: javaScript,
    link: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript',
  },
  ts: {
    name: 'TypeScript',
    location: typeScript,
    link: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript',
  },
  css3: {
    name: 'CSS3',
    location: css3,
    link: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript',
  },
  html5: {
    name: 'HTML5',
    location: html5,
    link: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript',
  },
  node: {
    name: 'node.js',
    location: node,
    link: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript',
  },
  next: {
    name: 'Next.js',
    location: next,
    link: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript',
  },
  mongodb: {
    name: 'MongoDb',
    location: mongodb,
    link: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript',
  },
  jest: {
    name: 'Jest',
    location: jest,
    link: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript',
  },
  reactBootstrap: {
    name: 'React-Bootstrap',
    location: reactBootstrap,
    link: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript',
  },
  reactRouter: {
    name: 'React-Router',
    location: reactRouter,
    link: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript',
  },
  redux: {
    name: 'Redux',
    location: redux,
    link: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript',
  },
  webpack: {
    name: 'Webpack',
    location: webpack,
    link: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript',
  },
  express: {
    name: 'Express',
    location: express,
    link: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript',
  },
  git: {
    name: 'git',
    location: git,
    link: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript',
  },
  github: {
    name: 'GitHub',
    location: github,
    link: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript',
  },
  postman: {
    name: 'Postman',
    location: postman,
    link: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript',
  },
};
