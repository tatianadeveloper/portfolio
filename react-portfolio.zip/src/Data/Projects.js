import React from '../images/icons/react.svg';
import Node from '../images/icons/nodejs.svg';
import { DataStack } from './Stack.js';

export const DataProjects = [
  {
    id: 0,
    name: 'Trello clone React',
    screenshot: '',
    description:
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec gravida vulputate nisl, eu ornare urna. Mauris ac nulla a sapien cursus tristique at ac enim.',
    stack: [
      DataStack.js,
      DataStack.react,
      DataStack.reactBootstrap,
      DataStack.html5,
      DataStack.css3,
    ],
    feature: [
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
    ],
  },
  {
    id: 1,
    name: 'Trello clone React',
    screenshot: '',
    description:
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec gravida vulputate nisl, eu ornare urna. Mauris ac nulla a sapien cursus tristique at ac enim.',
    stack: [
      DataStack.js,
      DataStack.react,
      DataStack.reactBootstrap,
      DataStack.html5,
      DataStack.css3,
    ],
    feature: [
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
    ],
  },
  {
    id: 2,
    name: 'Trello clone vanila JS',
    screenshot: '',
    description:
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec gravida vulputate nisl, eu ornare urna. Mauris ac nulla a sapien cursus tristique at ac enim.',
    stack: [
      DataStack.js,
      DataStack.react,
      DataStack.reactBootstrap,
      DataStack.html5,
      DataStack.css3,
    ],
    feature: [
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
    ],
  },
  {
    id: 3,
    name: 'Portfolio website React',
    screenshot: '',
    description:
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec gravida vulputate nisl, eu ornare urna. Mauris ac nulla a sapien cursus tristique at ac enim.',
    stack: [
      DataStack.js,
      DataStack.react,
      DataStack.reactBootstrap,
      DataStack.html5,
      DataStack.css3,
    ],
    feature: [
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
    ],
  },
];
